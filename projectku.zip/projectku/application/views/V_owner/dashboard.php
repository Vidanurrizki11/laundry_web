<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <a href="<?= base_url('Owner/pdfview_member'); ?>" class="btn btn-primary btn-sm"> Lihat Laporan</a>
            </div>

           

    </div>
    <!-- End of Main Content -->