<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="text-center"> Form Tambah Data Pelanggan</h1><br />
                <a class="btn btn-primary" href="<?php echo base_url() . 'Admin/pelanggan' ?>" role="button">kembali</a>
            </div>
        </div>
        <br />
        <form method="post" action="<?php echo base_url('admin/pelanggan_aksi') ?>" enctype="multipart/form-data">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <div class="mb-3 row">
                                <label for="staticEmail" class="col-sm-2 col-form-label">Id Pelanggan</label>
                                <div class="col-sm-10">
                                    <input type="text" name="id_member" class="form-control">
                                </div>
                                <?php echo form_error('id_member'); ?>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Nama</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputPassword" name="nama">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Alamat</label>
                                <div class="col-sm-10">
                                    <textarea type="text" class="form-control" id="inputPassword" name="alamat"> </textarea>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                                <div class="col-sm-10">
                                    <select class="form-select" aria-label="Default select example" name="jenis_kelamin">
                                        <option selected>Pilih Jenis Kelamin</option>
                                        <option value="L">Laki-Laki</option>
                                        <option value="P">Perempuan</option>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Nomor Telepon</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputPassword" name="tlp">
                                </div>
                            </div>
                            <input type="submit" class="btn btn-success " value="Update Data Pelanggan">
                        </div>
                    </div>
                </div>
        </form>
    </div>
    </div>
</body>

</html>