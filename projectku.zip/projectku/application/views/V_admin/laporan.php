<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah Laporan</a>
        </div>

        <div class="card-body">
            <div class="table-responsive">

                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <colgroup>
                        <col width="2%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th>Tanggal</th>
                            <th>No Transaksi</th>
                            <th>Jenis Paket</th>
                            <th>Total Bayar</th>
                            <th>Jumlah Uang</th>
                            <th>Pelanggan</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <th class="text-center" scope="row">1</th>
                            <td>29 Januari 2022</td>
                            <td>00075</td>
                            <td>Paket A</td>
                            <td>140.000</td>
                            <td>150.000</td>
                            <td>Handri</td>
                            <td class="text-center">
                                <button type="button" class="btn btn-default btn-sm btn-flat border-info wave-effect text-info dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                    Aksi
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" data-toggle="modal" data-target="">Edit</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" data-toggle="modal" data-target="">Hapus</a>
                                </div>
                            </td>
                        </tr>

                    </tbody>
                </table>


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->