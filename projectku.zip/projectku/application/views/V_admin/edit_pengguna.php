<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="text-center"> Form Update Data Pengguna</h1><br />
                <a class="btn btn-primary" href="<?php echo base_url() . 'Admin/pengguna' ?>" role="button">kembali</a>
            </div>
        </div>
        <br />
        <form method="post" action="<?php echo base_url('admin/pengguna_update') ?>" enctype="multipart/form-data">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <?php foreach ($nama as $u) { ?>
                                <div class="mb-3 row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">Id</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="id_user" class="form-control" value="<?php echo $u->id_user; ?>" readonly>
                                    </div>
                                    <?php echo form_error('id_user'); ?>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Nama</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="nama" value="<?php echo $u->nama; ?>">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Username</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="username" value="<?php echo $u->username; ?>">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="password" value="<?php echo $u->password; ?>">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Id Outlet</label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" name="id_outlet">
                                            <option selected><?php echo $u->id_outlet; ?></option>
                                            <?php foreach ($outlet as $o) : ?>
                                                <option value="<?= $o->id_outlet; ?>"><?= $o->id_outlet; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Posisi</label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" name="role">
                                            <option selected><?php echo $u->role; ?></option>
                                            <option value="Admin">Admin</option>
                                            <option value="Kasir">Kasir</option>
                                            <option value="Owner">Owner</option>
                                        </select>
                                    </div>
                                <?php } ?>
                                </div>
                                <input type="submit" class="btn btn-success " value="Simpan Data Pengguna">
                        </div>
                    </div>
                </div>
        </form>
    </div>
    </div>
</body>

</html>