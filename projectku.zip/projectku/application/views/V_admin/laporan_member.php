<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title; ?></title>
    <style>
        #table {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #table td,
        #table th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #table tr:hover {
            background-color: #ddd;
        }

        #table th {
            padding-top: 10px;
            padding-bottom: 10px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>

<body>
    <div style="text-align:center">
        <h3> Report Data Member/Pengguna</h3>
    </div>
    <table id="table">
        <thead>
            <tr>
                <th>No.</th>
                <th>Id Member</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Jenis Kelamin</th>
                <th>Telepon</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($member as $m) {
            ?>
                <tr>
                    <td scope="row"><?php echo $no++; ?></td>
                    <td><?php echo $m->id_member; ?></td>
                    <td><?php echo $m->nama; ?></td>
                    <td><?php echo $m->alamat; ?></td>
                    <td><?php echo $m->jenis_kelamin; ?></td>
                    <td><?php echo $m->tlp; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <body>
        <div style="text-align:center">
            <h3> Report Data Paket</h3>
        </div>
        <table id="table">
            <thead>
                <tr>
                    <th class="text-center">No</th>
                    <th>No Paket</th>
                    <th>No Outlet</th>
                    <th>Jenis</th>
                    <th>Nama Paket</th>
                    <th>Harga</th>
                </tr>
            </thead>
            <tbody>

                <?php
                $no = 1;
                foreach ($paket as $p) {
                ?>
                    <tr>
                        <th class="text-center" scope="row"><?php echo $no++; ?></th>
                        <td><?php echo $p->id_paket; ?></td>
                        <td><?php echo $p->id_outlet; ?></td>
                        <td><?php echo $p->jenis; ?></td>
                        <td><?php echo $p->nama_paket; ?></td>
                        <td><?php echo $p->harga; ?></td>
                    </tr>
                <?php } ?>

            </tbody>
        </table>

        <body>
            <div style="text-align:center">
                <h3> Report Data Outlet</h3>
            </div>
            <table id="table">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th>No Outlet</th>
                        <th>Nama Outlet</th>
                        <th>Alamat</th>
                        <th>No Telpon</th>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    $no = 1;
                    foreach ($outlet as $o) {
                    ?>
                        <tr>
                            <th class="text-center" scope="row"><?php echo $no++; ?></th>
                            <td><?php echo $o->id_outlet; ?></td>
                            <td><?php echo $o->nama; ?></td>
                            <td><?php echo $o->alamat; ?></td>
                            <td><?php echo $o->tlp; ?></td>
                        </tr>
                    <?php } ?>

                </tbody>
            </table>

            <body>
                <div style="text-align:center">
                    <h3> Report Data Transaksi</h3>
                </div>
                <table id="table">
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th>Kode Invoice</th>
                            <th>No Outlet</th>
                            <th>Id Member</th>
                            <th>Tanggal Order</th>
                            <th>Nama Paket</th>
                            <th>Berat/Jumlah Paket</th>
                            <th>Total Harga</th>
                            <th>Status</th>
                            <th>Pembayaran</th>
                        </tr>
                    </thead>
                    <tbody>


                        <?php
                        $no = 1;
                        foreach ($transaksi as $t) {
                        ?>
                            <tr>
                                <th scope="row"><?php echo $no++; ?></th>
                                <td><?php echo $t->kode_invoice; ?></td>
                                <td><?php echo $t->id_outlet; ?></td>
                                <td class="text-center"><?php echo $t->id_member; ?></td>
                                <td><?php echo $t->tgl; ?></td>
                                <td><?php echo $t->nama_paket; ?></td>
                                <td><?php echo $t->berat_paket; ?></td>
                                <td><?php echo $t->total_harga; ?></td>
                                <td><?php echo $t->status; ?></td>
                                <td><?php echo $t->dibayar; ?></td>
                            </tr>
                        <?php } ?>


                    </tbody>
                </table>

            </body>

</html>