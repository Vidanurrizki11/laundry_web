<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?= base_url('Admin/tambah_pelanggan'); ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah Pelanggan</a>
        </div>

        <div class="card-body">
            <div class="table-responsive">

                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <colgroup>
                        <col width="2%">
                        <col width="12%">
                        <col width="20%">
                        <col width="20%">
                        <col width="15%">
                        <col width="15%">
                        <col width="5%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th>Id pelanggan</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Jenis Kelamin</th>
                            <th>Telepon</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        $no = 1;
                        foreach ($member as $m) {
                        ?>
                            <tr>
                                <th scope="row"><?php echo $no++; ?></th>
                                <td><?php echo $m->id_member; ?></td>
                                <td><?php echo $m->nama; ?></td>
                                <td><?php echo $m->alamat; ?></td>
                                <td><?php echo $m->jenis_kelamin; ?></td>
                                <td><?php echo $m->tlp; ?></td>

                                <td class="text-center">
                                    <button type="button" class="btn btn-default btn-sm btn-flat border-info wave-effect text-info dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                        Aksi
                                    </button>
                                    <div class="dropdown-menu">
                                        <a href="<?php echo base_url() . 'Admin/edit_pelanggan/' . $m->id_member; ?>" class="dropdown-item">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a href="<?php echo base_url() . 'Admin/hapus_pelanggan/' . $m->id_member; ?>" class="dropdown-item">Hapus</a>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>

                    </tbody>
                </table>


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->