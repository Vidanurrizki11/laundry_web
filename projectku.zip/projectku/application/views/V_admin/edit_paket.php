<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="text-center"> Form Update Data Paket</h1><br />
                <a class="btn btn-primary" href="<?php echo base_url() . 'Admin/paket' ?>" role="button">kembali</a>
            </div>
        </div>
        <br />
        <form method="post" action="<?php echo base_url('admin/paket_update') ?>" enctype="multipart/form-data">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <?php foreach ($paket as $p) { ?>
                                <div class="mb-3 row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">Id Paket</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="id_paket" class="form-control" value="<?php echo $p->id_paket; ?>" readonly>
                                    </div>
                                    <?php echo form_error('id_paket'); ?>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Id Outlet</label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" name="id_outlet">
                                            <option selected><?php echo $p->id_outlet; ?></option>
                                            <?php foreach ($outlet as $o) : ?>
                                                <option value="<?= $o->id_outlet; ?>"><?= $o->id_outlet; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Jenis</label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" name="jenis">
                                            <option selected><?php echo $p->jenis; ?></option>
                                            <option value="kiloan">Kiloan</option>
                                            <option value="satuan">Satuan</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Nama Paket</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="nama_paket" value="<?php echo $p->nama_paket; ?>">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Harga</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="harga" value="<?php echo $p->harga; ?>">
                                    </div>
                                <?php } ?>
                                </div>
                                <input type="submit" class="btn btn-success " value="Simpan Data Paket">
                        </div>
                    </div>
                </div>
        </form>
    </div>
    </div>
</body>

</html>