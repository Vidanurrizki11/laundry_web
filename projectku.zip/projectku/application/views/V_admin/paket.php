<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?= base_url('Admin/tambah_paket'); ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah Paket</a>
        </div>

        <div class="card-body">
            <div class="table-responsive">

                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <colgroup>
                        <col width="2%">
                        <col width="5%">
                        <col width="5%">
                        <col width="5%">
                        <col width="15%">
                        <col width="5%">
                        <col width="5%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th>No Paket</th>
                            <th>No Outlet</th>
                            <th>Jenis</th>
                            <th>Nama Paket</th>
                            <th>Harga</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        $no = 1;
                        foreach ($paket as $p) {
                        ?>
                            <tr>
                                <th class="text-center" scope="row"><?php echo $no++; ?></th>
                                <td><?php echo $p->id_paket; ?></td>
                                <td><?php echo $p->id_outlet; ?></td>
                                <td><?php echo $p->jenis; ?></td>
                                <td><?php echo $p->nama_paket; ?></td>
                                <td><?php echo $p->harga; ?></td>
                                <td class="text-center">
                                    <button type="button" class="btn btn-default btn-sm btn-flat border-info wave-effect text-info dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                        Aksi
                                    </button>
                                    <div class="dropdown-menu">
                                        <a href="<?php echo base_url() . 'Admin/edit_paket/' . $p->id_paket; ?>" class="dropdown-item">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a href="<?php echo base_url() . 'Admin/hapus_paket/' . $p->id_paket; ?>" class="dropdown-item">Hapus</a>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>

                    </tbody>
                </table>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->