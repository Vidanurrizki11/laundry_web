<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="text-center"> Form Update Data Outlet</h1><br />
                <a class="btn btn-primary" href="<?php echo base_url() . 'Admin/outlet' ?>" role="button">kembali</a>
            </div>
        </div>
        <br />
        <form method="post" action="<?php echo base_url('admin/outlet_update') ?>" enctype="multipart/form-data">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <?php foreach ($outlet as $o) { ?>
                                <div class="mb-3 row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">Id Member</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="id_outlet" class="form-control" value="<?php echo $o->id_outlet; ?>" readonly>
                                    </div>
                                    <?php echo form_error('id_outlet'); ?>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Nama</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="nama" value="<?php echo $o->nama; ?>">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Alamat</label>
                                    <div class="col-sm-10">
                                        <textarea type="text" class="form-control" id="inputPassword" name="alamat"> <?php echo $o->alamat; ?></textarea>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Nomor Telepon</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="tlp" value="<?php echo $o->tlp; ?>">
                                    </div>
                                <?php } ?>
                                </div>
                                <input type="submit" class="btn btn-success " value="Simpan Data Outlet">
                        </div>
                    </div>
                </div>
        </form>
    </div>
    </div>
</body>

</html>