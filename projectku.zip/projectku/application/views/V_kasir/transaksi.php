<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?= base_url('Kasir/tambah_transaksi'); ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah Transaksi</a>
        </div>

        <div class="card-body">
            <div class="table-responsive">

                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <colgroup>
                        <col width="2%">
                        <col width="8%">
                        <col width="1%">
                        <col width="10%">
                        <col width="8%">
                        <col width="5%">
                        <col width="10%">
                        <col width="5%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th>Kode Invoice</th>
                            <th>Pelanggan</th>
                            <th>Total Harga</th>
                            <th>Status</th>
                            <th>Pembayaran</th>
                            <th>Tanggal Order</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>


                        <?php
                        $no = 1;
                        foreach ($transaksi as $t) {
                        ?>
                            <tr>

                                <th scope="row"><?php echo $no++; ?></th>
                                <td><?php echo $t->kode_invoice; ?></td>
                                <td class="text-center"><?php echo $t->id_member; ?></td>
                                <td><?php echo $t->total_harga; ?></td>
                                <td><?php echo $t->status; ?></td>
                                <td><?php echo $t->dibayar; ?></td>
                                <td><?php echo $t->tgl; ?></td>


                                <td class="text-center">
                                    <a href="<?php echo base_url() . 'Kasir/edit_transaksi/' . $t->id_transaksi; ?>" class="btn btn-primary btn-sm">detail</a>
                                </td>
                            </tr>
                        <?php } ?>


                    </tbody>
                </table>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->