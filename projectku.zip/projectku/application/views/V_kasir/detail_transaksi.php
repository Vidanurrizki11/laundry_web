<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="text-center"> Detail Transaksi</h1><br />
                <a class="btn btn-primary" href="<?php echo base_url() . 'Kasir/transaksi' ?>" role="button">kembali</a>
            </div>
        </div>
        <br />
        <form method="post" action="<?php echo base_url('kasir/transaksi_update') ?>" enctype="multipart/form-data">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <?php foreach ($transaksi as $t) { ?>
                                <div class="mb-3 row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">Id Transaksi</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="id_transaksi" class="form-control" value="<?php echo $t->id_transaksi; ?>" readonly>
                                    </div>
                                    <?php echo form_error('id_transaksi'); ?>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Kode Invoice</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="kode_invoice" value="<?php echo $t->kode_invoice; ?>" readonly> </input>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">No Outlet</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" autocomplete="off" name="id_outlet" value="<?php echo $t->id_outlet; ?>" readonly> </input>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">Id Member</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" autocomplete="off" name="id_member" value="<?php echo $t->id_member; ?>" readonly> </input>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Tanggal Order</label>
                                    <div class="col-sm-10">
                                        <input type="date" class="form-control" autocomplete="off" name="tgl" value="<?php echo $t->tgl; ?>" readonly> </input>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Nama Paket</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="nama_paket" value="<?php echo $t->nama_paket; ?>" readonly> </input>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Berat/Jumlah Paket</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="berat_paket" value="<?php echo $t->berat_paket; ?>" readonly> </input>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Total Harga</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="total_harga" value="<?php echo $t->total_harga; ?>" readonly> </input>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Status</label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" name="status">
                                            <option selected><?php echo $t->status; ?></option>
                                            <option value="baru">Baru</option>
                                            <option value="proses">Proses</option>
                                            <option value="selesai">Selesai</option>
                                            <option value="diambil">Diambil</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Pembayaran</label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" name="dibayar">
                                            <option selected><?php echo $t->dibayar; ?></option>
                                            <option value="belum">Belum</option>
                                            <option value="dibayar">Dibayar</option>
                                        </select>
                                    </div>
                                <?php } ?>
                                </div>
                                <input type="submit" class="btn btn-success " value="Update Data Transaksi">
                        </div>
                    </div>
                </div>
        </form>
    </div>
    </div>
</body>

</html>