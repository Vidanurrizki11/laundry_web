<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Owner extends CI_Controller
{

    function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Jakarta');

        $this->load->model('m_data');

        //cek session yang login,
        // jika session status tidak sama dengan session telah_login, berarti pengguna belum login
        // maka halaman akan di alihkan kembali ke halaman login.
        if ($this->session->userdata('status') != "telah_login") {
            redirect(base_url() . 'login?alert=belum_login');
        }
    }

    public function index()
    {
        $data['title'] = 'Laporan';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_owner', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_owner/dashboard');
        $this->load->view('templates/footer_owner');
    }

    public function laporan()
    {
        $data['title'] = 'Laporan';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_owner', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_owner/laporan_member');
        $this->load->view('templates/footer_owner');
    }

    // fungsi PDFView
    public function pdfview_member()
    {
        $data['title'] = 'Laporan';
        // panggil library yang kita buat sebelumnya yang bernama pdfgenerator
        $this->load->library('pdfgenerator');

        // title dari pdf
        $this->data['title_pdf'] = 'Laporan Penjualan Toko Kita';

        // filename dari pdf ketika didownload
        $file_pdf = 'laporan_member';
        // setting paper
        $paper = 'A4';
        //orientasi paper potrait / landscape
        $orientation = "portrait";

        $data['member'] = $this->m_data->get_data('tb_member')->result();
        $data['paket'] = $this->m_data->get_data('tb_paket')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $html = $this->load->view('V_owner/laporan_member', $data, true);

        // run dompdf
        $this->pdfgenerator->generate($html, $file_pdf, $paper, $orientation);
    }

    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('login?alert=logout');
    }
}
