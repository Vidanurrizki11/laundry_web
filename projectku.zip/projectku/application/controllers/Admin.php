<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Jakarta');

        $this->load->model('m_data');

        //cek session yang login,
        // jika session status tidak sama dengan session telah_login, berarti pengguna belum login
        // maka halaman akan di alihkan kembali ke halaman login.
        if ($this->session->userdata('status') != "telah_login") {
            redirect(base_url() . 'login?alert=belum_login');
        }
    }

    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['total_outlet'] = $this->m_data->jumlahoutlet();
        $data['total_pelanggan'] = $this->m_data->jumlahpelanggan();
        $data['total_transaksi'] = $this->m_data->jumlahtransaksi();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/dashboard');
        $this->load->view('templates/footer_admin');
    }

    public function pelanggan()
    {
        $data['title'] = 'Pelanggan';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['member'] = $this->m_data->get_data('tb_member')->result();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/pelanggan');
        $this->load->view('templates/footer_admin');
    }

    public function tambah_pelanggan()
    {
        $data['title'] = 'Tambah Pelanggan';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/tambah_pelanggan', $data);
        $this->load->view('templates/footer_admin');
    }

    public function pelanggan_aksi()
    {
        $data['title'] = 'Tambah Pelanggan';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

        //validasi input
        $this->form_validation->set_rules('id_member', 'id_member', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('alamat', 'alamat', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required');
        $this->form_validation->set_rules('tlp', 'tlp', 'required');
        //chek kondisi validasi
        if ($this->form_validation->run() != false) {
            //ambil input dariform
            $id_member = $this->input->post('id_member');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $jenis_kelamin = $this->input->post('jenis_kelamin');
            $tlp = $this->input->post('tlp');
            // data yang di simpan ke DB
            $data = array(
                'id_member' => $id_member,
                'nama' => $nama,
                'alamat' => $alamat,
                'jenis_kelamin' => $jenis_kelamin,
                'tlp' => $tlp
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data, 'tb_member');
            // halaman di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/pelanggan');
        } else {
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/tambah_pelanggan', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function edit_pelanggan($id_member) // mengambil data dari button edit
    {
        $data['title'] = 'Edit Pelanggan';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['member'] = $this->m_data->get_data('tb_member')->result();
        $where = array(
            'id_member' => $id_member
        );

        $data['member'] = $this->m_data->edit_data($where, 'tb_member')->result(); // perintah ambil data dari tabel member
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/edit_pelanggan', $data);
        $this->load->view('templates/footer_admin');
        // kondisi data yang akan di ambil dari database
    }

    public function pelanggan_update()
    {
        $data['title'] = 'Edit Pelanggan';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

        //validasi update
        $this->form_validation->set_rules('id_member', 'id_member', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('alamat', 'alamat', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required');
        $this->form_validation->set_rules('tlp', 'tlp', 'required');
        // chek kondisi validasi
        if ($this->form_validation->run() != false) {
            // ambil dara fari form edit member
            $id_member = $this->input->post('id_member');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $jenis_kelamin = $this->input->post('jenis_kelamin');
            $tlp = $this->input->post('tlp');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_member' => $id_member
            );
            // data yang akan di update
            $data = array(
                'nama' => $nama,
                'alamat' => $alamat,
                'jenis_kelamin' => $jenis_kelamin,
                'tlp' => $tlp
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data, 'tb_member');
            // di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/pelanggan');
        } else {
            // jika validasi update tidak berhasil 
            $id_member = $this->input->post('id_member');
            // kondisi data yang akan di ambil
            $where = array(
                'id_member' => $id_member
            );
            // perintah untuk mengambil data dari database
            $data['member'] = $this->m_data->edit_data($where, 'tb_member')->result();
            // halaman di alihkan ke form edit member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/edit_pelanggan', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function hapus_pelanggan($id_member)
    {
        $where = array(
            'id_member' => $id_member
        );

        $this->m_data->delete_data($where, 'tb_member');

        redirect(base_url() . 'Admin/pelanggan');
    }
    // END CRUD Member

    public function outlet()
    {
        $data['title'] = 'Outlet';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/outlet');
        $this->load->view('templates/footer_admin');
    }

    public function tambah_outlet()
    {
        $data['title'] = 'Tambah Outlet';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/tambah_outlet', $data);
        $this->load->view('templates/footer_admin');
    }

    public function outlet_aksi()
    {
        $data['title'] = 'Tambah Outlet';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

        //validasi input
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('alamat', 'alamat', 'required');
        $this->form_validation->set_rules('tlp', 'tlp', 'required');
        //chek kondisi validasi
        if ($this->form_validation->run() != false) {
            //ambil input dariform
            $id_outlet = $this->input->post('id_outlet');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $tlp = $this->input->post('tlp');
            // data yang di simpan ke DB
            $data = array(
                'id_outlet' => $id_outlet,
                'nama' => $nama,
                'alamat' => $alamat,
                'tlp' => $tlp
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data, 'tb_outlet');
            // halaman di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/outlet');
        } else {
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/tambah_outlet', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function edit_outlet($id_outlet) // mengambil data dari button edit
    {
        $data['title'] = 'Edit Outlet';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $where = array(
            'id_outlet' => $id_outlet
        );

        $data['outlet'] = $this->m_data->edit_data($where, 'tb_outlet')->result(); // perintah ambil data dari tabel member
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/edit_outlet', $data);
        $this->load->view('templates/footer_admin');
        // kondisi data yang akan di ambil dari database
    }

    public function outlet_update()
    {
        $data['title'] = 'Edit Outlet';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

        //validasi update
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('alamat', 'alamat', 'required');
        $this->form_validation->set_rules('tlp', 'tlp', 'required');
        // chek kondisi validasi
        if ($this->form_validation->run() != false) {
            // ambil dara fari form edit member
            $id_outlet = $this->input->post('id_outlet');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $tlp = $this->input->post('tlp');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_outlet' => $id_outlet
            );
            // data yang akan di update
            $data = array(
                'nama' => $nama,
                'alamat' => $alamat,
                'tlp' => $tlp
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data, 'tb_outlet');
            // di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/outlet');
        } else {
            // jika validasi update tidak berhasil 
            $id_outlet = $this->input->post('id_outlet');
            // kondisi data yang akan di ambil
            $where = array(
                'id_outlet' => $id_outlet
            );
            // perintah untuk mengambil data dari database
            $data['outlet'] = $this->m_data->edit_data($where, 'tb_outlet')->result();
            // halaman di alihkan ke form edit member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/edit_outlet', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function hapus_outlet($id_outlet)
    {
        $where = array(
            'id_outlet' => $id_outlet
        );

        $this->m_data->delete_data($where, 'tb_outlet');

        redirect(base_url() . 'Admin/outlet');
    }
    // END CRUD Member

    public function paket()
    {
        $data['title'] = 'Paket Cucian';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['paket'] = $this->m_data->get_data('tb_paket')->result();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/paket');
        $this->load->view('templates/footer_admin');
    }

    public function tambah_paket()
    {
        $data['title'] = 'Tambah Outlet';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/tambah_paket', $data);
        $this->load->view('templates/footer_admin');
    }

    public function paket_aksi()
    {
        $data['title'] = 'Tambah Outlet';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();


        //validasi input
        $this->form_validation->set_rules('id_paket', 'id_paket', 'required');
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
        $this->form_validation->set_rules('jenis', 'jenis', 'required');
        $this->form_validation->set_rules('nama_paket', 'nama_paket', 'required');
        $this->form_validation->set_rules('harga', 'harga', 'required');
        //chek kondisi validasi
        if ($this->form_validation->run() != false) {
            //ambil input dariform
            $id_paket = $this->input->post('id_paket');
            $id_outlet = $this->input->post('id_outlet');
            $jenis = $this->input->post('jenis');
            $nama_paket = $this->input->post('nama_paket');
            $harga = $this->input->post('harga');
            // data yang di simpan ke DB
            $data = array(
                'id_paket' => $id_paket,
                'id_outlet' => $id_outlet,
                'jenis' => $jenis,
                'nama_paket' => $nama_paket,
                'harga' => $harga,
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data, 'tb_paket');
            // halaman di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/paket');
        } else {
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/tambah_paket', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function edit_paket($id_paket) // mengambil data dari button edit
    {
        $data['title'] = 'Edit Paket';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['paket'] = $this->m_data->get_data('tb_paket')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $where = array(
            'id_paket' => $id_paket
        );

        $data['paket'] = $this->m_data->edit_data($where, 'tb_paket')->result(); // perintah ambil data dari tabel member
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/edit_paket', $data);
        $this->load->view('templates/footer_admin');
        // kondisi data yang akan di ambil dari database
    }

    public function paket_update()
    {
        $data['title'] = 'Edit Paket';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();

        //validasi update
        $this->form_validation->set_rules('id_paket', 'id_paket', 'required');
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
        $this->form_validation->set_rules('jenis', 'jenis', 'required');
        $this->form_validation->set_rules('nama_paket', 'nama_paket', 'required');
        $this->form_validation->set_rules('harga', 'harga', 'required');
        // chek kondisi validasi
        if ($this->form_validation->run() != false) {
            // ambil dara fari form edit member
            $id_paket = $this->input->post('id_paket');
            $id_outlet = $this->input->post('id_outlet');
            $jenis = $this->input->post('jenis');
            $nama_paket = $this->input->post('nama_paket');
            $harga = $this->input->post('harga');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_paket' => $id_paket
            );
            // data yang akan di update
            $data = array(
                'id_outlet' => $id_outlet,
                'jenis' => $jenis,
                'nama_paket' => $nama_paket,
                'harga' => $harga,
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data, 'tb_paket');
            // di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/paket');
        } else {
            // jika validasi update tidak berhasil 
            $id_paket = $this->input->post('id_paket');
            // kondisi data yang akan di ambil
            $where = array(
                'id_paket' => $id_paket
            );
            // perintah untuk mengambil data dari database
            $data['paket'] = $this->m_data->edit_data($where, 'tb_paket')->result();
            // halaman di alihkan ke form edit member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/edit_paket', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function hapus_paket($id_paket)
    {
        $where = array(
            'id_paket' => $id_paket
        );

        $this->m_data->delete_data($where, 'tb_paket');

        redirect(base_url() . 'Admin/paket');
    }
    // END CRUD Member


    public function pengguna()
    {
        $data['title'] = 'Pengguna';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['nama'] = $this->m_data->get_data('tb_user')->result();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/pengguna', $data);
        $this->load->view('templates/footer_admin');
    }

    public function tambah_pengguna()
    {
        $data['title'] = 'Tambah Pengguna';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/tambah_pengguna', $data);
        $this->load->view('templates/footer_admin');
    }

    public function pengguna_aksi()
    {
        $data['title'] = 'Tambah Pengguna';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();

        //validasi input
        $this->form_validation->set_rules('id_user', 'id_user', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('username', 'username', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
        $this->form_validation->set_rules('role', 'role', 'required');
        //chek kondisi validasi
        if ($this->form_validation->run() != false) {
            //ambil input dariform
            $id_user = $this->input->post('id_user');
            $nama = $this->input->post('nama');
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $id_outlet = $this->input->post('id_outlet');
            $role = $this->input->post('role');
            // data yang di simpan ke DB
            $data = array(
                'id_user' => $id_user,
                'nama' => $nama,
                'username' => $username,
                'password' => md5($password),
                'id_outlet' => $id_outlet,
                'role' => $role,
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data, 'tb_user');
            // halaman di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/pengguna');
        } else {
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/tambah_pengguna', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function edit_pengguna($id_user) // mengambil data dari button edit
    {
        $data['title'] = 'Edit Pengguna';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['nama'] = $this->m_data->get_data('tb_user')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $where = array(
            'id_user' => $id_user
        );

        $data['nama'] = $this->m_data->edit_data($where, 'tb_user')->result(); // perintah ambil data dari tabel member
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/edit_pengguna', $data);
        $this->load->view('templates/footer_admin');
        // kondisi data yang akan di ambil dari database
    }

    public function pengguna_update()
    {
        $data['title'] = 'Edit Pengguna';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();

        //validasi update
        $this->form_validation->set_rules('id_user', 'id_user', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('username', 'username', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
        $this->form_validation->set_rules('role', 'role', 'required');
        // chek kondisi validasi
        if ($this->form_validation->run() != false) {
            // ambil dara fari form edit member
            $id_user = $this->input->post('id_user');
            $nama = $this->input->post('nama');
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $id_outlet = $this->input->post('id_outlet');
            $role = $this->input->post('role');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_user' => $id_user
            );
            // data yang akan di update
            $data = array(
                'nama' => $nama,
                'username' => $username,
                'password' => md5($password),
                'id_outlet' => $id_outlet,
                'role' => $role,
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data, 'tb_user');
            // di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/pengguna');
        } else {
            // jika validasi update tidak berhasil 
            $id_user = $this->input->post('id_user');
            // kondisi data yang akan di ambil
            $where = array(
                'id_user' => $id_user
            );
            // perintah untuk mengambil data dari database
            $data['nama'] = $this->m_data->edit_data($where, 'tb_user')->result();
            // halaman di alihkan ke form edit member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/edit_pengguna', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function hapus_pengguna($id_user)
    {
        $where = array(
            'id_user' => $id_user
        );

        $this->m_data->delete_data($where, 'tb_user');

        redirect(base_url() . 'Admin/pengguna');
    }



    public function transaksi()
    {
        $data['title'] = 'Transaksi';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['member'] = $this->m_data->get_data('tb_member')->result();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/transaksi');
        $this->load->view('templates/footer_admin');
    }

    public function tambah_transaksi()
    {
        $data['title'] = 'Tambah Transaksi';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['member'] = $this->m_data->get_data('tb_member')->result();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/tambah_transaksi', $data);
        $this->load->view('templates/footer_admin');
    }

    public function transaksi_aksi()
    {
        $data['title'] = 'Tambah Transaksi';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['member'] = $this->m_data->get_data('tb_member')->result();

        //validasi input
        $this->form_validation->set_rules('id_transaksi', 'id_transaksi', 'required');
        $this->form_validation->set_rules('kode_invoice', 'kode_invoice', 'required');
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
        $this->form_validation->set_rules('id_member', 'id_member', 'required');
        $this->form_validation->set_rules('tgl', 'tgl', 'required');
        $this->form_validation->set_rules('nama_paket', 'nama_paket', 'required');
        $this->form_validation->set_rules('berat_paket', 'berat_paket', 'required');
        $this->form_validation->set_rules('total_harga', 'total_harga', 'required');
        $this->form_validation->set_rules('status', 'status', 'required');
        $this->form_validation->set_rules('dibayar', 'dibayar', 'required');
        //chek kondisi validasi
        if ($this->form_validation->run() != false) {
            //ambil input dariform
            $id_transaksi = $this->input->post('id_transaksi');
            $kode_invoice = $this->input->post('kode_invoice');
            $id_outlet = $this->input->post('id_outlet');
            $id_member = $this->input->post('id_member');
            $tgl = $this->input->post('tgl');
            $nama_paket = $this->input->post('nama_paket');
            $berat_paket = $this->input->post('berat_paket');
            $total_harga = $this->input->post('total_harga');
            $status = $this->input->post('status');
            $dibayar = $this->input->post('dibayar');
            // data yang di simpan ke DB
            $data = array(
                'id_transaksi' => $id_transaksi,
                'kode_invoice' => $kode_invoice,
                'id_outlet' => $id_outlet,
                'id_member' => $id_member,
                'tgl' => $tgl,
                'nama_paket' => $nama_paket,
                'berat_paket' => $berat_paket,
                'total_harga' => $total_harga,
                'status' => $status,
                'dibayar' => $dibayar,
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data, 'tb_transaksi');
            // halaman di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/transaksi');
        } else {
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/tambah_transaksi', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function edit_transaksi($id_transaksi) // mengambil data dari button edit
    {
        $data['title'] = 'Edit Pengguna';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['member'] = $this->m_data->get_data('tb_member')->result();
        $where = array(
            'id_transaksi' => $id_transaksi
        );

        $data['transaksi'] = $this->m_data->edit_data($where, 'tb_transaksi')->result(); // perintah ambil data dari tabel member
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/detail_transaksi', $data);
        $this->load->view('templates/footer_admin');
        // kondisi data yang akan di ambil dari database
    }

    public function transaksi_update()
    {
        $data['title'] = 'Edit Pengguna';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['member'] = $this->m_data->get_data('tb_member')->result();

        //validasi update
        $this->form_validation->set_rules('id_transaksi', 'id_transaksi', 'required');
        $this->form_validation->set_rules('status', 'status', 'required');
        $this->form_validation->set_rules('dibayar', 'dibayar', 'required');
        // chek kondisi validasi
        if ($this->form_validation->run() != false) {
            // ambil dara fari form edit member
            $id_transaksi = $this->input->post('id_transaksi');
            $status = $this->input->post('status');
            $dibayar = $this->input->post('dibayar');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_transaksi' => $id_transaksi
            );
            // data yang akan di update
            $data = array(
                'status' => $status,
                'dibayar' => $dibayar,
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data, 'tb_transaksi');
            // di arahkan ke halaman admin member
            redirect(base_url() . 'Admin/transaksi');
        } else {
            // jika validasi update tidak berhasil 
            $id_transaksi = $this->input->post('id_transaksi');
            // kondisi data yang akan di ambil
            $where = array(
                'id_transaksi' => $id_transaksi
            );
            // perintah untuk mengambil data dari database
            $data['transaksi'] = $this->m_data->edit_data($where, 'tb_transaksi')->result();
            // halaman di alihkan ke form edit member
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar_admin', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('V_admin/detail_transaksi', $data);
            $this->load->view('templates/footer_admin');
        }
    }

    public function laporan()
    {
        $data['title'] = 'Laporan';
        $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar_admin', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('V_admin/laporan');
        $this->load->view('templates/footer_admin');
    }

    // fungsi PDFView
    public function pdfview_member()
    {
        $data['title'] = 'Laporan';
        // panggil library yang kita buat sebelumnya yang bernama pdfgenerator
        $this->load->library('pdfgenerator');

        // title dari pdf
        $this->data['title_pdf'] = 'Laporan Penjualan Toko Kita';

        // filename dari pdf ketika didownload
        $file_pdf = 'laporan_member';
        // setting paper
        $paper = 'A4';
        //orientasi paper potrait / landscape
        $orientation = "portrait";

        $data['member'] = $this->m_data->get_data('tb_member')->result();
        $data['paket'] = $this->m_data->get_data('tb_paket')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $html = $this->load->view('V_admin/laporan_member', $data, true);

        // run dompdf
        $this->pdfgenerator->generate($html, $file_pdf, $paper, $orientation);
    }


    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('login?alert=logout');
    }
}
